# API_Final_Project

## commands
sudo rm -r API_Detector_Package.egg-info/ build dist </br>
python3 setup.py bdist_wheel sdist </br>
pip install . </br>